# Homework01
Homework 1: Setup &amp; Rounding Error

Click on Homework_01.ipynb above to access the homework assignment.
